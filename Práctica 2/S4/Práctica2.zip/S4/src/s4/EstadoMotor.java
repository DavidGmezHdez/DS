package s4;
public enum EstadoMotor {
    ACELERANDO,
    APAGADO,
    FRENANDO,
    ENCENDIDO,
    CONSTANTE,
    MANTENIENDO,
    ANDANDO
}
