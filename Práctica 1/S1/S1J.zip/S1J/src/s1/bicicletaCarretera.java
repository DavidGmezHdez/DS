package s1;

public class bicicletaCarretera extends Bicicleta {
    
    bicicletaCarretera(int id){
        super(id);
    }
    
}