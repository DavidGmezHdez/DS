package s1;
import java.util.ArrayList;
public interface factoriaCarrerayBicicleta {
            
    public abstract Carrera crearCarrera(int codigo);

    public abstract Bicicleta crearBicicleta(int id);
    
}