package s1;

public class bicicletaMontana extends Bicicleta {
    
    bicicletaMontana(int id){
        super(id);
    }
}