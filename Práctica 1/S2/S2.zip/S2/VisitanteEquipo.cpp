#include "VisitanteEquipo.h"

VisitanteEquipo::~VisitanteEquipo(){
    delete this;
}