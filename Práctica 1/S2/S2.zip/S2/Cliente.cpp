#include "Cliente.h"

Cliente::Cliente(string nom, float d){
    this->nombre = nom;
    this->descuento = d;
}