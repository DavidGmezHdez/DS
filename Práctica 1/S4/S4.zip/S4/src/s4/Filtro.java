package s4;
public interface Filtro {
    float incremento = 0;
    public double ejecturar(double revoluciones,EstadoMotor estadoMotor);
}
