package s4;
public class Cliente  {
    public static GUISalpicadero salpicadero;
    
    public static void main(String[] args) {
        salpicadero =  new GUISalpicadero();
        salpicadero.main(new String[0]);
    }
}
